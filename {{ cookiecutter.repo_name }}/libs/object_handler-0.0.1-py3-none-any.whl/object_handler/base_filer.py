import enum
from serialize import dumps, loads, dump, load
from typing import Any
from object_handler.types_ooh import IntKEY, NullKEY

class FilerOp(enum.Enum):
    """Available operation using the encoder"""
    Save = 1
    Clone = 2
    Copy = 3
    REST = 4

class QSFiler(object):
    """
    Class that handles the encoder.\n
    Supperted encoders:\n
    -None using python dict()\n
    -bson using https://pypi.python.org/pypi/bson\n
    -dill using https://pypi.python.org/pypi/dill\n
    -json using https://docs.python.org/3/library/json.html\n
    -msgpack using https://pypi.python.org/pypi/msgpack-python\n
    -phpserialize using https://pypi.python.org/pypi/phpserialize\n
    -pickle using https://docs.python.org/3/library/pickle.html\n
    -serpent using https://pypi.python.org/pypi/serpent\n
    -yaml using https://pypi.python.org/pypi/pyyaml\n
    """
    # constructor:
    def __init__(self, encoder, buffering = FilerOp.Save):
        # engine/encoder
        self.__encoder_type = encoder
        self.__buffering = buffering
        # metadata:
        self.__obj_type = None
        self.__obj_parents = None
        self.__obj_key:IntKEY = NullKEY #None

        # data: buffer/list
        self.__obj_data = list()    #dict()
        
        # internal counter
        self.__next_pop:int = 0 #None

    @property
    def Encoder(self):
        """Get the type of the encoder"""
        return self.__encoder_type
    
    @property
    def Operator(self):
        """Get the buffering"""
        return self.__buffering

    @property
    def ObjType(self):
        """Get the object type"""
        return self.__obj_type
    def SetObjType(self, objname:str):
        """Set the object type"""
        self.__obj_type = objname

    @property
    def ObjParents(self):
        """Get the object parents"""
        return self.__obj_parents
    def SetObjParents(self, parentlist):
        """Set the object parents"""
        self.__obj_parents = parentlist
    
    @property
    def ObjKey(self) -> IntKEY:
        """Get the object key"""
        return self.__obj_key
    def SetObjKey(self, key: IntKEY):
        """Set the object key"""
        self.__obj_key = key

    @property
    def ObjData(self):
        """Get the object data"""
        return self.__obj_data

    def pop(self):
        """Pop a variable from the object data"""
        value = self.__obj_data[self.__next_pop]
        self.__next_pop += 1
        return value

    def push(self, value:Any):
        """Push a variable in the object data"""
        # tags = len(self.__obj_data)
        # self.__obj_data[tags] = value
        self.__obj_data.append(value)

    def _blob_out(self):
        """Get the object in self"""
        return dict(Key=self.ObjKey, Type=self.ObjType, Data=self.ObjData)

    def _blob_in(self, x):
        """Set the obj in self"""
        self.SetObjKey(x['Key'])
        self.SetObjType(x['Type'])
        self.__obj_data = x['Data']
        # self.__obj_parents = x['Parents']

    @staticmethod
    def _build_filename(key, enc):
        """prepare the filename used by the filer"""
        filename = 'filer.' + str(key) + '.' + enc
        return filename

    def DecodeFromFile(self, datadir:str=""):
        """Decode an object from frile"""
        x = None
        fname = self._build_filename(self.ObjKey, self.Encoder)
        with open(datadir+fname, 'rb') as fp:
            x = load(fp, fmt=self.Encoder)
        self._blob_in(x)
        self.__next_pop = 0

    def EncodeToFile(self, datadir:str=""):
        """Encode an object to file"""
        fname = self._build_filename(self.ObjKey, self.Encoder)
        with open(datadir+fname, 'wb') as fp:
            dump(self._blob_out(), fp, fmt=self.Encoder)

    def Encode(self):
        """Encode the object"""
        if self.Encoder is None:
            return self._blob_out()
        return dumps(self._blob_out(), fmt=self.Encoder)

    def Decode(self, blob_in):
        """Decode the object"""
        x = None
        if self.Encoder is None:
            # todo: fix <field name> from mongo collection
            x = blob_in
        else:
            x = loads(blob_in, fmt=self.Encoder)
        self._blob_in(x)
        self.__next_pop = 0
