# from serialize import load, dump
import os
from typing import Tuple, Dict, List, Any, Optional
from .base_filer import QSFiler
from object_handler.base_obj_handler import ObjectBuilder, BaseObjectHandler, BaseKey
import object_handler as ooh

class FileObjectHandler(BaseObjectHandler):
    """Class used to handle object saved in a Dictionary"""
    def __init__(self, datadir:str="", encoder=None, builder:Optional[ObjectBuilder]=None):
        super().__init__(storage=ooh.StorageMode.Dict, encoder=encoder)
        self.store:Dict[ooh.IntKEY,Any] = {}
        actual_datadir = datadir   #+"//pickler//"
        if os.path.exists(actual_datadir):
            self.DataDir = actual_datadir
            for root, dirs, files in os.walk(actual_datadir):
                for file in files:
                    ints = [int(s) for s in file.split(sep=".") if s.isdigit()]
                    if ints:
                        f_id:int = ints[0]
                        self.store[f_id] = "" #os.path.join(root,file)
        
        kmax = max(self.store.keys()) if self.store else 0
        self.ResetCount(kmax)

        self._builder = builder
    
    def __len__(self)->int:
          return len(self.store)
    
    def OpenObjectId(self, keyobj:ooh.BaseKey, mode:ooh.OpenMode=ooh.OpenMode.ForWrite) ->Optional[ooh.IObject]:
        obj = None
        f2 = QSFiler(self.Encoder)
        f2.SetObjKey(keyobj())
        f2.DecodeFromFile(datadir=self.DataDir)

        # obj = globals()[f2.ObjType]()
        obj = self._builder.Build(f2.ObjType)
        obj.InFields(f2)
        obj.Status=mode
        f2 = None
        return obj

    def _on_write(self, obj:ooh.IObject) ->Tuple[ooh.IntKEY, Any]:
        tname = obj.ClassName
        f = QSFiler(self.Encoder)
        f.SetObjType(tname)
        obj.OutFields(f)
        f.EncodeToFile(datadir=self.DataDir)
        key_to_store = obj.Id
        # f = None
        return key_to_store, None

    def Close(self, obj:ooh.IObject) ->None:
        if obj.Status == ooh.OpenMode.ForWrite or obj.Status == ooh.OpenMode.New:
            _, _ = self._on_write(obj)
            # self.store[obj_key] = obj_to_store
            obj.Status = ooh.OpenMode.Closed

    def _internal_keys(self) ->List[ooh.IntKEY]:
        return list(self.store.keys())
    
    def BaseKeys(self, cls:ooh.TGenericObject=None) ->List[ooh.BaseKey]:
        res = []
        all_keys = self._internal_keys() #list(self.store.keys())
        if cls is None:
            res = all_keys
        else:
            filtered_keys:List[ooh.IntKEY] = []
            for xk in all_keys:  #self._internal_keys():
                obj = self.OpenObjectId(ooh.BaseKey(xk), mode=ooh.OpenMode.ForRead)
                if (obj is not None):
                    if isinstance(obj, cls):
                        filtered_keys.append( xk )
                    self.Close(obj)
            res = filtered_keys
        return [ooh.BaseKey(ik) for ik in res]


    def DeleteObjectId(self, key:BaseKey) ->None:
        if self.store.get(key()) is not None:
            self.store.pop(key())
    
    def Clear(self) ->None:
        self.store.clear()
        self.ResetCount()