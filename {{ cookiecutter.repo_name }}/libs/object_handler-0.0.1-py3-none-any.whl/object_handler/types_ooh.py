import enum
from typing import Union

IntKEY = int
NullKEY = -1

class BaseKey(object):
    """Handling Base Key, referred as native format"""
    __internal_key:IntKEY = NullKEY

    def __init__(self, value:IntKEY = NullKEY) -> None:
        self.__internal_key = value

    def asIntKey(self) -> IntKEY:
        return self.__internal_key

    # to override !
    def __call__(self) -> IntKEY:
        return self.__internal_key

    def fromInt(self, value:IntKEY) -> None:
        self.__internal_key = value

    def fromStr(self, value:str) -> None:
        self.__internal_key = int(value)

class StorageMode(enum.Enum):
    """Available storage encoders"""
    Dict = 1
    File = 2
    MongoDB = 3
    Memory = 4

class OpenMode(enum.Enum):
    """How to open an object"""
    New = 1
    ForRead = 2
    ForWrite = 3
    Closed = 4

TStorage = Union[None, StorageMode]