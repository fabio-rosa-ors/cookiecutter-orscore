from typing import Dict, List, Optional
from object_handler.base_obj_handler import IObject, ObjectBuilder, BaseObjectHandler, BaseKey
import object_handler as ooh

class MemObjectHandler(BaseObjectHandler):
    """Object handler based on memory (type: "MEM")"""
    def __init__(self, encoder=None, builder:Optional[ObjectBuilder]=None):
        super().__init__(storage=ooh.StorageMode.Memory, encoder=None)
        self.store:Dict[ooh.IntKEY,ooh.IObject] = {}
        self._builder = None
    
    def __len__(self):
          return len(self.store)
          
    def OpenObjectId(self, keyobj:ooh.BaseKey, mode:ooh.OpenMode=ooh.OpenMode.ForWrite) ->Optional[ooh.IObject]:
        obj = self.store.get(keyobj())
        if obj is not None:
            obj.Status=mode
        return obj
    
    def _on_write(self, obj):
        key_to_store = ooh.BaseKey(obj.Id)()
        return key_to_store, obj

    def Close(self, obj:IObject) ->None:
        if obj.Status == ooh.OpenMode.ForWrite or obj.Status == ooh.OpenMode.New:
            obj_key, obj_to_store = self._on_write(obj)
            self.store[obj_key] = obj_to_store
            obj.Status = ooh.OpenMode.Closed
    
    def _internal_keys(self) ->List[ooh.IntKEY]:
        return list(self.store.keys())

    def BaseKeys(self, cls:ooh.TGenericObject=None) ->List[ooh.BaseKey]:
        res = []
        all_keys = self._internal_keys() #list(self.store.keys())
        if cls is None:
            res = all_keys
        else:
            filtered_keys:List[ooh.IntKEY] = []
            for xk in all_keys:  #self._internal_keys():
                obj = self.store.get(xk)
                if (obj is not None) and isinstance(obj, cls):
                    filtered_keys.append( xk )
            res = filtered_keys
        return [ooh.BaseKey(ik) for ik in res]

    def DeleteObjectId(self, key:BaseKey) ->None:
        if self.store.get(key()) is not None:
            self.store.pop(key())
    
    def Clear(self) ->None:
        self.store.clear()
        self.ResetCount()
