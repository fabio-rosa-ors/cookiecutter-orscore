from dataclasses import dataclass
import os
import sys
from typing import Any, Dict, List
import importlib
import pkg_resources
import json

@dataclass
class PluginConfig:
	name: str
	file_path: str
	req_path: str
	constructor: Any = None

class PluginsHandler():
	""" Class PluginHandler
	
		Handle imports and requirements check for a list of plugins

		Each plugin must have a folder with its name under the plugin_dir
		Inside the plugin folder, should be:
		- the plugin module
		- the requirements.txt file
		- __init__.py file which exposes the plugin methods or classes
	"""
	def __init__(self, plugin_dir: str, required_plugins: List[str]) -> None:
		""" Initialize the PluginsHandler and handle the required plugins (check requirements and import)
			Args:
				plugin_dir (str): the plugins directory
				required_plugins (List[str]): list of the required plugins names
		"""
		ws = pkg_resources.working_set
		self.installed_packages = ["%s==%s" % (i.key, i.version) for i in ws]
		self.registry = None
		registry_path = os.path.join(plugin_dir, 'registry.json')
		if os.path.exists(registry_path):
			with open(registry_path) as f:
				self.registry = json.load(f)
		else:
			raise Exception('Missing plugins registry')

		self.plugin_dir: str = plugin_dir
		self.available_plugins: Dict[str, PluginConfig] = {}
		if os.path.isdir(plugin_dir):
			available_plugins = [f for f in os.listdir(plugin_dir) if os.path.isdir(os.path.join(plugin_dir, f)) and '__' not in f]
			for p in available_plugins:
				self.available_plugins[p] = PluginConfig(name=p, 
											file_path=os.path.join(plugin_dir, p, f'{self.registry[p]["module"]}.py'),
											req_path=os.path.join(plugin_dir, p, 'requirements.txt'))

		self.required_plugins: List[str] = required_plugins
		self._handle()

	def _handle(self) -> None:
		""" Check for plugins availability. 
			If a required plugin is available in the plugins directory:
			 - get the plugin configuration (PluginConfig)
			 - check for installed packages from requirements.txt
			 - import the plugin module 
		"""
		num_available = len(self.available_plugins)
		num_required = len(self.required_plugins)
		if num_required == 0:
			return
		if num_available == 0:
			diff_list = ', '.join(list(set(self.required_plugins).difference(self.available_plugins)))
			raise Exception(f'Missing plugins: {diff_list}')

		for p in self.required_plugins:
			if p in self.available_plugins:
				plugin: PluginConfig = self.available_plugins[p]
				if self._has_valid_requirements(plugin=plugin):
					self._import(plugin=plugin)
			else:
				raise Exception(f'Missing plugin: {p}')
		
	def _import(self, plugin: PluginConfig) -> None:
		""" Import the plugin module from the plugin configuration 
			and register the handler's constructors in the PluginConfig (get the main class name from the json registry)

			Args:
				plugin (PluginConfig)
		"""
		spec:Any = importlib.util.spec_from_file_location(plugin.name, plugin.file_path)
		mod:Any = importlib.util.module_from_spec(spec)
		sys.modules[plugin.name]=mod
		spec.loader.exec_module(mod)
		plugin.constructor = getattr(mod, self.registry[plugin.name]['class'])

	def _has_valid_requirements(self, plugin: PluginConfig) -> bool:
		""" Check whether the required packages for the plugin are already installed 
			Otherwise, returns an exception listing the missing packages
			Args:
				plugin (PluginConfig)
			Return:
				bool
		"""
		is_valid = True
		missing_reqs = []
		with open(plugin.req_path, encoding='utf-8') as f:
			for line in f:
				req = line.split("#", 1)[0].strip()
				if req and not req.startswith("--") and req not in self.installed_packages:
					missing_reqs.append(req)
					if is_valid:
						is_valid = False
		if len(missing_reqs) > 0:
			missings = ", ".join(missing_reqs)
			raise Exception(f'Plugin "{plugin.name}" requires the following packages: {missings}')

		return is_valid

	def is_required_and_valid(self, plugin_name: str) -> bool:
		""" Check if a plugin has been required and whether the plugin exists in the plugins directory 
			Args:
				plugin_name (str): the plugin name (i.e. the plugin's folder name)
			Returns:
				bool
		"""
		return plugin_name in self.required_plugins and plugin_name in self.available_plugins

	def create(self, plugin_name: str, **kwargs) -> Any:
		""" Create an instance of the required plugin with its parameters 
		
			Args:
				plugin_name (str): the plugin name (directory name)
				**kwargs: the plugin parameters
			
			Return:
				instance of the required object
		"""
		return self.available_plugins[plugin_name].constructor(**kwargs)