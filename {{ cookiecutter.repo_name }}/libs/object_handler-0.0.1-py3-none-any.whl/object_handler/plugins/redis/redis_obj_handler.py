import redis as red
from typing import List, Optional

from object_handler.base_filer import QSFiler
from object_handler.base_obj_handler import IObject, ObjectBuilder, BaseObjectHandler
import object_handler as ooh
from bson.objectid import ObjectId

class RedisKey(ooh.BaseKey):
    """Handling of mongoDB keys"""
    def __init__(self, value):
        super().__init__(int(str(value)))

    # to override !
    def __call__(self):
        return str(self.asIntKey()).zfill(24)

    def fromInt(self, value):
        super().__init__(value)

class RedisObjectHandler(BaseObjectHandler):
    """Object handler based on Redis (type: "Redis")"""

    DEFAULT_HOST="127.0.0.1"
    DEFAULT_PORT=6379
    DEFAULT_DB=0

    @staticmethod
    def get_available_projects(host, port, db):
        client = red.Redis(host, port)
        collections = client.config_get('databases')
        collections = client.info('keyspace')
        return list(collections.keys())

    def __init__(self, session_id, host:str=DEFAULT_HOST, port:int=DEFAULT_PORT, db:int=DEFAULT_DB, query_timeout:int=6000, builder:Optional[ObjectBuilder]=None):
        """Object handler based on MongoDB"""
        super().__init__(storage=ooh.StorageMode.MongoDB, encoder='dill')
        # todo: 
        # connect(....)
        self.client = red.Redis(host, port, db)
        self.query_timeout = query_timeout

        ks = [int(k) for k in self.client.scan_iter('*')]
        if ks:
            # if connected to already existing project need to update the key counter
            kmax = max(ks)
            self.ResetCount(kmax)
        
        self._builder = builder

    def __len__(self):
        #   return len(self.keys())
        return self.client.info('keyspace')['keys']

    def OpenObjectId(self, keyobj:ooh.BaseKey, mode:ooh.OpenMode=ooh.OpenMode.ForWrite) ->ooh.IObject:
        #
        obj = None
        obj_key:RedisKey = RedisKey(keyobj.asIntKey()) 
        obj_stored = self.client.get(obj_key())
        if obj_stored is not None:
            f2 = QSFiler(self.Encoder)
            f2.Decode(obj_stored["obj"])
            obj:IObject = self._builder.Build(f2.ObjType)
            obj.InFields(f2)
            obj.Status=mode
            f2 = None
        return obj
    
    def _on_write(self, obj):
        """Write obj in the ObjectHandler"""
        f = QSFiler(self.Encoder)
        f.SetObjType(obj.__class__.__name__)
        # f.SetObjParents(obj.__class__.__bases__)
        obj.OutFields(f)
        obj_to_store = f.Encode()
        key_to_store = RedisKey(obj.Id)()
        f = None
        return key_to_store, obj_to_store

    def Close(self, obj:IObject) ->None:
        if obj.Status in [ooh.OpenMode.New, ooh.OpenMode.ForWrite]:
            obj_key, obj_to_store = self._on_write(obj)
            self.client.set(obj_key, obj_to_store)
        obj.Status=ooh.OpenMode.Closed
    
    def _internal_keys(self) ->List[RedisKey]:
        """Get the available Keys in the Mongo pointed by the object handler"""
        return [RedisKey(key) for key in self.client.scan_iter('*')]

    def BaseKeys(self, cls:ooh.TGenericObject=None) ->List[RedisKey]:
        res = []
        all_keys:List[RedisKey] = self._internal_keys()
        if cls is None:
            res = all_keys
        else:
            filtered_keys:List[RedisKey] = []
            for xk in all_keys:
                obj = self.OpenObjectId(xk, mode=ooh.OpenMode.ForRead)
                if (obj is not None):
                    if isinstance(obj, cls):
                        filtered_keys.append( xk )
                    self.Close(obj)
            res = filtered_keys
        return res

    def DeleteObjectId(self, key:ooh.BaseKey) ->None:
        obj_key:RedisKey = RedisKey(key.asIntKey()) 
        self.client.delete(obj_key())
    
    def Clear(self) ->None:
        """Drop the collection and reset the counter of ids"""
        pipe = self.client.pipeline()
        for key in self.client.scan_iter('*'):
            pipe.delete(key)
        pipe.execute()
        self.ResetCount() # ===> self.__counter = -1
