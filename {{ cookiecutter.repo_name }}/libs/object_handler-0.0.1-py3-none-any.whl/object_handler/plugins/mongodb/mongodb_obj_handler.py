from pymongo import MongoClient, CursorType
from pymongo.errors import ConnectionFailure

from bson.objectid import ObjectId
from bson.binary import Binary
from typing import List, Optional, Union

from object_handler.base_filer import QSFiler
from object_handler.base_obj_handler import IObject, ObjectBuilder, BaseObjectHandler
import object_handler as ooh
from pymongo.cursor import CursorType


class MongoKey(ooh.BaseKey):
    """Handling of mongoDB keys"""
    # mongokey are usually built from int (e.g. ooh.IntKey)
    # ...but could also come from DB string keys:  MongoKey( self.coll.find(projection=["_id"],.... )
    def __init__(self, value:Union[int,str]):
        # double int/str check ???
        super().__init__(int(str(value)))

    # transform the internal (int) key represantation into the corresponding mongodb identifier, e.g.:
    # 12 --> "00000...0012"
    def __call__(self):
        return ObjectId(str(self.asIntKey()).zfill(24))

    def fromInt(self, value):
        super().__init__(value)

class MongoDBObjectHandler(BaseObjectHandler):
    """Object handler based on MongoDB (type: "MONGODB")"""
    @staticmethod
    def get_available_projects(host, port, db):
        client = MongoClient(host, port)
        collections = client[db]
        return collections.collection_names()

    def __init__(self, session_id, host:str='localhost', port:int=27017, db:str='TradingObjects', query_timeout:int=6000, builder:Optional[ObjectBuilder]=None, encoder="dill"):
        """Object handler based on MongoDB"""
        super().__init__(storage=ooh.StorageMode.MongoDB, encoder=encoder)
        # connect(....)
        self.client = MongoClient(host=host, port=port, serverSelectionTimeoutMS=5000)
        try:
            self.client.admin.command('ismaster')
        except ConnectionFailure as e:
            self.client = None
            print("MongoDB connection error: host="+host+" port="+str(port))
            print(e)

        if self.client is not None:
            self.db = self.client[db]
            self.coll = self.db[session_id]
            self.query_timeout = query_timeout

            doc = self.coll.find_one(sort=[("_id", -1)], max_time_ms=self.query_timeout)
            if doc is not None:
                # if connected to already existing project need to update the key counter
                kmax = int(str(doc["_id"]))
                self.ResetCount(kmax)
            
            # Mongo automatically index the _id field !
            # else:
            #     # build index when coll still empty
            #     self.coll.create_index("_id", unique = True)

            self._builder = builder

    def __len__(self):
          return self.coll.count_documents({})

    def OpenObjectId(self, keyobj:ooh.BaseKey, mode:ooh.OpenMode=ooh.OpenMode.ForWrite) ->ooh.IObject:
        #
        obj = None
        obj_key:MongoKey = MongoKey(keyobj.asIntKey()) 
        obj_stored = self.coll.find_one(filter={"_id":obj_key()}, max_time_ms=self.query_timeout)
        # obj_stored = list(self.coll.find(filter={"_id":obj_key()}))[0]
        if obj_stored is not None:
            f2 = QSFiler(self.Encoder) #, self.Count())
            f2.Decode(obj_stored["obj"])
            # obj = globals()[f2.ObjType]()
            obj:IObject = self._builder.Build(f2.ObjType)
            try:
                obj.InFields(f2)
            except Exception as e:
                print(e)
                
            obj.Status=mode
            f2 = None
        return obj
    
    def _on_write(self, obj:IObject):
        """Write obj in the ObjectHandler"""
        f = QSFiler(self.Encoder)
        f.SetObjType(obj.__class__.__name__)
        # f.SetObjParents(obj.__class__.__bases__)
        obj.OutFields(f)
        obj_to_store = f.Encode()
        key_to_store = MongoKey(obj.Id)()
        f = None
        return key_to_store, obj_to_store

    def Close(self, obj:IObject) ->None:
        # obj_key, obj_to_store = self._on_write(obj)
        if obj.Status == ooh.OpenMode.ForWrite:
            obj_key, obj_to_store = self._on_write(obj)
            self.coll.update_one({"_id":obj_key}, { "$set": {"obj":Binary(obj_to_store)} } )
        elif obj.Status == ooh.OpenMode.New:
            obj_key, obj_to_store = self._on_write(obj)
            self.coll.insert_one({"_id":obj_key, "obj":Binary(obj_to_store)})
        obj.Status=ooh.OpenMode.Closed
    
    def _internal_keys(self) ->List[MongoKey]:
        """Get the available MongoKeys in the Mongo pointed by the object handler"""
        return [MongoKey(x["_id"]) for x in self.coll.find(projection=["_id"], cursor_type=CursorType.EXHAUST, max_time_ms=self.query_timeout)]

    def BaseKeys(self, cls:ooh.TGenericObject=None) ->List[MongoKey]:
        res = []
        all_keys:List[MongoKey] = self._internal_keys()
        if cls is None:
            res = all_keys
        else:
            filtered_keys:List[MongoKey] = []
            for xk in all_keys:
                obj = self.OpenObjectId(xk, mode=ooh.OpenMode.ForRead)
                if (obj is not None):
                    if isinstance(obj, cls):
                        filtered_keys.append( xk )
                    self.Close(obj)
            res = filtered_keys
        return res

    def DeleteObjectId(self, key:ooh.BaseKey) ->None:
        obj_key:MongoKey = MongoKey(key.asIntKey()) 
        self.coll.delete_one(obj_key())
    
    def Clear(self) ->None:
        """Drop the collection and reset the counter of ids"""
        self.coll.drop()
        self.ResetCount() # ===> self.__counter = -1
