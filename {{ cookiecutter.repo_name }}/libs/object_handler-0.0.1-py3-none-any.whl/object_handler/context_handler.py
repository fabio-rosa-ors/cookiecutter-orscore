from typing import Any, Dict, List, Optional
import os
import importlib
import sys
import object_handler as ooh
from object_handler.plugins import PluginsHandler

class ContextHandler:

	@property
	def ProjectStore(self) ->Optional[ooh.BaseObjectHandler]:
		"""Get the PRJ_STORE configured"""
		return self.conf_container.PRJ_STORE

	@property
	def ClassBuilder(self) ->Optional[ooh.IObjectBuilder]:
		"""Get the OBJECT_STORE configured"""
		return self.conf_container.CLASS_BUILDER

	@property
	def ObjectStore(self) ->Optional[ooh.BaseObjectHandler]:
		"""Get the OBJECT_STORE configured"""
		return self.conf_container.OBJECT_STORE

	def __init__(self, from_env: bool = True, from_dict: Dict = None, enable_plugins: List[str] = []) -> None:
		self.conf_container = None

		# build engine helper
		NEW_CONF = ooh.ContextConfig({})

		if from_env:
			# Project name
			NEW_CONF.PRJ_NAME = os.getenv('PRJ_NAME') or NEW_CONF.PRJ_NAME
			# Data paths
			NEW_CONF.DATA_DIR = os.getenv('DATA_DIR') or NEW_CONF.DATA_DIR
			NEW_CONF.OUTPUT_DIR = os.getenv('OUTPUT_DIR') or NEW_CONF.OUTPUT_DIR
			NEW_CONF.PLUGIN_DIR = os.getenv('PLUGIN_DIR') or NEW_CONF.PLUGIN_DIR
			# DB
			NEW_CONF.DB_HOST = os.getenv('DB_HOST') or NEW_CONF.DB_HOST
			if os.getenv('QUERY_TIMEOUT') is not None:
				NEW_CONF.QUERY_TIMEOUT = int(os.getenv('QUERY_TIMEOUT'))
			if os.getenv('DB_PORT') is not None:
				NEW_CONF.DB_PORT = int(os.getenv('DB_PORT'))
			# Logs
			NEW_CONF.LOG_STORE_TYPE = os.getenv('LOG_STORE_TYPE') or NEW_CONF.LOG_STORE_TYPE
			# First key
			if os.getenv('OBJECT_COUNTER') is not None:
				NEW_CONF.OBJECT_COUNTER = int(os.getenv('OBJECT_COUNTER'))
			# Memory without persistence
			NEW_CONF.OBJECT_STORE_TYPE = os.getenv('OBJECT_STORE_TYPE') or NEW_CONF.OBJECT_STORE_TYPE
			# Memory with persistence
			NEW_CONF.PRJ_STORE_TYPE = os.getenv('PRJ_STORE_TYPE') or NEW_CONF.PRJ_STORE_TYPE
		
		if from_dict is not None:
			NEW_CONF = ooh.ContextConfig(from_dict)

		# handle plugins
		self._plugins_handler: PluginsHandler = PluginsHandler(plugin_dir=NEW_CONF.PLUGIN_DIR, required_plugins=enable_plugins)

		# object-store generator
		NEW_OBJ_Builder = ooh.ObjectBuilder()
		# create data-handlers from configuration
		NEW_OBJECT_STORE= ContextHandler._build_engine(self, engine_type=NEW_CONF.OBJECT_STORE_TYPE, CONF=NEW_CONF, TheBuilder=NEW_OBJ_Builder)
		NEW_PRJ_STORE 	= ContextHandler._build_engine(self, engine_type=NEW_CONF.PRJ_STORE_TYPE, CONF=NEW_CONF, TheBuilder=NEW_OBJ_Builder)
		NEW_LOG_STORE = None    
		NEW_LOGGER:Dict[str,Any] = {}  

		self.conf_container:ooh.ContextContainer = ooh.ContextContainer.from_dict({
									**NEW_CONF.to_dict(),
									"CLASS_BUILDER" : NEW_OBJ_Builder,
									"OBJECT_STORE" 	: NEW_OBJECT_STORE,
									"PRJ_STORE" 	: NEW_PRJ_STORE,
									"LOG_STORE" 	: NEW_LOG_STORE,
									"LOGGER" 		: NEW_LOGGER })

		ooh.SET_AS_DEFAULT(self.conf_container)


	def _build_engine(self, engine_type:str, CONF:ooh.ContextConfig, TheBuilder:ooh.ObjectBuilder) ->Optional[ooh.IObjectHandler]:
		"""Build the engine. An object handler is returned, based on its type.

		Args:
			engine_type (str): Available types: "MEM_DICT", "MONGODB", "MEM"
			conf
			id_prj (str): if engine_type is "MONGODB", set here the session id
			TheBuilder (ooh.ObjectBuilder): an object builder. See ObjectBuilder.

		Returns:
			Optional[ooh.IObjectHandler]: A base object, based on the engine type provided.
		"""
		res = None

		if engine_type == "MEM_DICT": #ooh.StorageMode.Dict:
			res = ooh.DictObjectHandler(
				encoder=None,
				builder=TheBuilder)
		elif engine_type == "MEM": #ooh.StorageMode.Memory:
			res = ooh.MemObjectHandler(
				encoder=None,
				builder=None)
		elif engine_type == "MONGODB": #ooh.StorageMode.MongoDB:
			plugin_name = engine_type.lower()
			if self._plugins_handler.is_required_and_valid(plugin_name=plugin_name):
				mongo_host =  CONF.DB_HOST
				mongo_port =  CONF.DB_PORT
				mongo_db =   "TradingObjects"
				res = self._plugins_handler.create(plugin_name=plugin_name,
					session_id=CONF.PRJ_NAME,
					host=mongo_host,
					port=mongo_port,
					db=mongo_db,
					query_timeout=CONF.QUERY_TIMEOUT,
					builder=TheBuilder,
					encoder="pickle")
		elif engine_type == "FILE":
			file_dir =  CONF.DATA_DIR+"//pickler//" 
			res = ooh.FileObjectHandler(
				datadir=file_dir,
				builder=TheBuilder,
				encoder="pickle")
		return res

	def EXPORT(self, project_store:Optional[ooh.BaseObjectHandler]) -> List[Optional[int]]:
		"""Save a project

		Args:
			project_store (Optional[ooh.BaseObjectHandler]): projects to be saved. Dest.
		
		Returns:
			List[Optional[int]]: list of ids related with the saved strategy
		"""
		dumped = list()
		project_store.Clear()
		for obj_id in self.ObjectStore.BaseKeys():
			obj = ooh.OPENK(key=obj_id, engine=self.ObjectStore, mode=ooh.OpenMode.ForRead)
			if obj is not None:
				# trigger save ops
				dest_key = ooh.ADDK(obj, obj.Id, project_store)
				dumped.append( (obj_id, dest_key) )
				
		return(dumped)

	def IMPORT(self, project_store:Optional[ooh.BaseObjectHandler]=None)->List[Any]: 
		"""Load a BaseObjectHandler

		Args:
			project_store (Optional[ooh.BaseObjectHandler]):
		"""
		dumped:List[Any] = []
		from_store = self.ProjectStore if project_store is None else project_store
		to_store = self.ObjectStore
		
		if (from_store is not None) and (to_store is not None):
			to_store.Clear()
			a = from_store.BaseKeys()
			b = [item.asIntKey() for item in a ]
			max_counter = max(b) if b else 0
			to_store.ResetCount(max_counter)

			for src_key in from_store.BaseKeys():
				obj = ooh.OPENK(key=src_key, engine=from_store, mode=ooh.OpenMode.ForRead)
				if obj is not None:
					# aggiungo alla sessione
					dest_key = ooh.ADDK(obj, obj.Id, engine=to_store)
					dumped.append( (src_key, dest_key) )
		return(dumped)

	def REGISTER(self, class_name:str, class_type:Any) -> None:
		""" Register a class inside the configuration container 
			This allows the container to able to recreate it on-demand when the class object is load from the storage

			Args:
				class_name (str): the name of the class
				class_type (Any): the class

			Example:
				class MyClass():
					def __init__():
						# something
					
					def func():
						# do something
						
				my_conf.REGISTER("MyClass", MyClass)
		"""
		self.conf_container.CLASS_BUILDER.Register(class_name, class_type)