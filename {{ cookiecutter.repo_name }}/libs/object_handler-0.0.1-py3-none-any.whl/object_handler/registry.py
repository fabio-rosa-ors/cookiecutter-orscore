"""Containers module."""

# -------------------------------------------------------------------------------------
# Registries
# -------------------------------------------------------------------------------------        
# 
from class_registry import ClassRegistry
from class_registry import EntryPointClassRegistry

BaseRegistry = ClassRegistry(attr_name='__name__')
Pred = EntryPointClassRegistry('predictors')
Opt = EntryPointClassRegistry('optimizers')
Core = EntryPointClassRegistry('components')
Stat = EntryPointClassRegistry('statistics')
Sim = EntryPointClassRegistry('simulations')
