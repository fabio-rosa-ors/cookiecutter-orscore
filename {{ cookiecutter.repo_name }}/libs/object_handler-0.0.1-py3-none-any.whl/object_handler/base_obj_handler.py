from contextlib import contextmanager
from object_handler.types_ooh import IntKEY, NullKEY, BaseKey, TStorage, OpenMode
from object_handler.base_filer import QSFiler

from typing import Optional, TypeVar, List, Any, Dict
from typing_extensions import TypedDict
from abc import ABC, abstractmethod, abstractproperty
from datastruct import DataStruct
import datetime as dt
#
from class_registry import AutoRegister
from object_handler.registry import BaseRegistry
# import threading

class extend_docstring:
	"""Class used to extend the documentation"""
	def __init__(self, method):
		self.doc = method.__doc__

	def __call__(self, function):
		if self.doc is not None:
			doc = function.__doc__
			function.__doc__ = self.doc
			if doc is not None:
				function.__doc__ += doc
		return function

class BaseCounter(object):

	def __init__(self, initial_count:IntKEY = -1):
		self._counter:int = initial_count
	
	def Count(self) -> IntKEY:
		"""Get the counter"""
		return self._counter

	def NextCount(self) -> IntKEY:
		"""Iterate over the counter and get the next value"""
		key = self._counter+1
		self._counter = key
		return key

	def ResetCount(self, initial_count:IntKEY = -1):
		"""Reset the counter count"""
		self._counter = initial_count

class ILogger(ABC):
	"""Abstract logger class"""

	def info(self, msg:str, *args:Any, **kwargs:Any):
		raise NotImplementedError("Should implement info method")

	def warning(self, msg:str, *args:Any, **kwargs:Any):
		"""
		Log 'msg % args' with severity 'WARNING'.

		To pass exception information, use the keyword argument exc_info with
		a true value, e.g.

		logger.warning("Houston, we have a %s", "bit of a problem", exc_info=1)
		"""
		raise NotImplementedError("Should implement warning method")

	def error(self, msg:str, *args:Any, **kwargs:Any):
		"""
		Log 'msg % args' with severity 'ERROR'.

		To pass exception information, use the keyword argument exc_info with
		a true value, e.g.

		logger.error("Houston, we have a %s", "major problem", exc_info=1)
		"""
		raise NotImplementedError("Should implement error method")

	def exception(self, msg:str, *args:Any, exc_info:bool=True, **kwargs:Any):
		"""
		Convenience method for logging an ERROR with exception information.
		"""
		raise NotImplementedError("Should implement exception method")

class IObject(metaclass=AutoRegister(BaseRegistry)):

	class Setup(TypedDict):
		pass


	"""
	Base interface for every ORS Trading class
	"""
	@property
	@abstractmethod
	def ClassName(self) ->str:
		raise NotImplementedError("Should implement ClassName method")

	@abstractproperty
	def Descriptor(self)->Dict[str,Any]:
		raise NotImplementedError("Should implement Descriptor method")

	@property
	@abstractmethod
	def Id(self) -> IntKEY:
		raise NotImplementedError("Should implement Id method")
	@Id.setter
	def Id(self, id:IntKEY) -> None:
		raise NotImplementedError("Should implement Id setter method")

	@property
	@abstractmethod
	def Name(self) -> str:
		raise NotImplementedError("Should implement Name method")
	@Name.setter
	def Name(self, val:str) -> None:
		raise NotImplementedError("Should implement Name setter method")
	
	@property
	@abstractmethod
	def Status(self) -> OpenMode:
		raise NotImplementedError("Should implement Status method")
	
	@Status.setter
	@abstractmethod
	def Status(self, openmode:OpenMode) -> None:
		raise NotImplementedError("Should implement Status setter method")

	def Defaults(self) ->Setup:
		raise NotImplementedError("Should implement Default method")
	
	@abstractmethod
	def setup(self, params:Optional[TypedDict]) -> Any:
		"""
		Fuction useful for setup the object.

		Args:
			params (Optional[TypedDict]): params in a Setup format to build the object

		"""
		raise NotImplementedError("Should implement setup method")

	@abstractmethod
	def InFields(self, filer:QSFiler)->bool:
		"""
		Variables to be saved with the object in the filer, using filer.push().
		The items are extracted in the same order in which they were saved.

		Args:
			filer (QSFiler): encoder used to save the object.

		Returns:
			Bool: True if everything goes well
		"""
		raise NotImplementedError("Should implement InFields method")

	@abstractmethod
	def OutFields(self, filer:QSFiler)->bool:
		"""
		Get the variables saved with the object in the filer, using filer.pop(). 
		The items are extracted in the same order in which they were saved.

		Args:
			filer (QSFiler): encoder used to extract the object.

		Returns:
			Bool: True if everything goes well
		"""
		raise NotImplementedError("Should implement OutFields method")
	
	@abstractmethod
	def on_delete(self)->None:
		raise NotImplementedError("Should implement on_delete method")

class BaseObject(IObject):
	"""
	Base serialized class
	"""

	class Setup(TypedDict, total=False):
		"""
		TypedDict used to initialize the setup function params  
		"""
		name:str
		"""name of the object"""
		name_variant:str
		name_creator:str
		creation_time:Optional[dt.datetime]

	def Defaults(self) ->Setup:
		"""
		Function that returns an initialized Setup TypedDict with the default values.
		"""
		return BaseObject.Setup(
			name="",
			name_variant="",
			name_creator="",
			creation_time=None )

	__version = 2

	@property
	def ClassName(self) ->str:
		"""Get the name of the class of the object"""
		return self.__class__.__name__

	# object properties:
	@property
	def Id(self) -> IntKEY:
		"""Get the id associated with the object"""
		return self.__id
	@Id.setter
	def Id(self, id:IntKEY) -> None:
		"""Set the id of an object"""
		self.__id = id
	

	@property
	def Name(self) -> str:
		"""Get the name of an object"""
		return self._name
	@Name.setter
	def Name(self, val:str) -> None:
		"""Set the name of an object"""
		self._name = val


	@property
	def Status(self) -> OpenMode:
		"""
		Fuction that returns the OpenMode of an object
		"""
		return self.__status
	@Status.setter
	def Status(self, openmode:OpenMode) -> None:
		"""Set the status of the object"""
		self.__status = openmode


	@property
	def Descriptor(self)->Dict[str,Any]:
		"""Get a description of an object. If will be a dictionary that contains Name, ClassName and Id"""
		res = {"Name":self.Name, "Type":self.ClassName, "Id":self.Id}
		return res

	def _init_state(self, id:IntKEY=NullKEY):
		# non serializzato
		self.__status:OpenMode = OpenMode.New
		# serializzati:
		self.__id:IntKEY = id
		self._name:str = ""
		self._name_variant:str = ""
		self._name_creator:str = ""
		self._creation_time:Optional[dt.datetime] = None


	@staticmethod
	def _init_setup(obj:IObject, from_setup:Optional[TypedDict]=None, from_default:bool=False):
		if from_setup is not None:
			obj.setup(params=from_setup)
		elif from_default:
			obj.setup(params=obj.Defaults())

	@staticmethod
	def _apply_setup(obj:IObject, params:Optional[Setup]=None)->Any:
		actual_params = obj.Defaults()
		if params is not None:
			actual_params.update(params)
		return actual_params

	# constructor:
	def __init__(self, from_setup:Optional[TypedDict]=None, from_default:bool=False, id:IntKEY=NullKEY):
		super().__init__()
		BaseObject._init_state(self, id)
		BaseObject._init_setup(obj=self, from_setup=from_setup, from_default=from_default)

	@extend_docstring(IObject.setup)
	def setup(self, params:Optional[Setup]=None) -> Any:
		"""
		Here the log_id and the name are initialize. 
		"""
		# 1
		# super().setup(params)
		# 2
		actual_params = BaseObject._apply_setup(obj=self, params=params)
		# 3
		self._name = actual_params["name"]
		self._name_variant:str = ""
		self._name_creator:str = ""
		self._creation_time:Optional[dt.datetime] = None
		# 4
		return self

	@property
	def log_id(self)->IntKEY:
		"""Get the log_id associated with the actual object. NB: a project can handle different logs, so different groups of object can have a different handling of the log"""
		res = NullKEY
		try:
			log_list = DEFAULT().LOG_TOPICS
			if len(log_list)>0:
				res = 0 #"default"
				if self.ClassName in log_list:
					res = log_list.index(self.ClassName)
		except Exception as e:
			print("log_id() issue:",e)
			res = NullKEY
		return res

	def InFields(self, filer:QSFiler):
		# check status
		# assertRead

		# check version
		stored_version:int = filer.pop()
		if stored_version == BaseObject.__version:
			self.Id = filer.ObjKey
			self._name = filer.pop()
			self._name_variant = filer.pop()
			self._name_creator = filer.pop()
			self._creation_time = filer.pop()
		elif stored_version == 1:
			self.Id = filer.ObjKey
			self._name = filer.pop()
		elif stored_version == 0:
			self.Id = filer.ObjKey
			tmp = filer.pop() # self.log_id
			tmp = None
			self._name = filer.pop()
		return True

	def OutFields(self, filer:QSFiler):
		filer.SetObjKey(self.Id)
		filer.push(BaseObject.__version)
		filer.push(self._name)
		filer.push(self._name_variant)
		filer.push(self._name_creator)
		filer.push(self._creation_time)
		return True
	
	# def VersionUpgrade(self, from:int, filer:QSFiler):
	#     pass

	def on_delete(self)->None:
		pass

	@property
	def logged(self) -> bool:
		"""If the object should be logged. Now it is always True"""
		return True
		# dovrebbe funzionare, ma per ora logghiamo tutto
		# return self.log_id != NullKEY

	def LogInfo(self, msg:str, topic:str="Default"):
		"""Log the msg in input as an Info. 

		Args:
			msg (str): message to output
			topic (str, optional): topc that describes where the message should be log. Now only the default logger is used. Defaults to "Default".
		"""
		if self.logged:
			log:ILogger
			log = DEFAULT().LOGGER.get(topic)
			if log is not None:
				log.info(msg)
	
	def LogWarning(self, msg:str, topic:str="Default"):
		"""Log the msg in input as an Warning. 

		Args:
			msg (str): message to output
			topic (str, optional): topic that describes where the message should be log. Now only the default logger is used. Defaults to "Default".
		"""
		if self.logged:
			log:ILogger
			log = DEFAULT().LOGGER.get(topic)
			if log is not None:
				log.warning(msg)
	
	def LogError(self, msg:str, topic:str="Default"):
		"""Log the msg in input as an Error. 

		Args:
			msg (str): message to output
			topic (str, optional): topic that describes where the message should be log. Now only the default logger is used. Defaults to "Default".
		"""
		print(msg)
		if self.logged:
			log:ILogger
			log = DEFAULT().LOGGER.get(topic)
			if log is not None:
				log.error(msg)
	
TGenericObject = TypeVar('TGenericObject', bound=IObject, contravariant=True)

class ObjectDictionary(BaseObject):
	""" Class used to handle an object using a object_dictionary:Dict[str, IntKey]"""

	class Setup(BaseObject.Setup, total=True):
		pass

	def Defaults(self)->Setup:
		return ObjectDictionary.Setup( **super().Defaults() )

	__version = 2

	def _init_state(self):
		self._topics:Dict[str, Dict[str, IntKEY]] = {} # _topics["topic-label"]["name"] --> IntKEY
	   
	def __init__(self, from_setup:Optional[Setup]=None, from_default:bool=False):
		super().__init__(from_setup=None, from_default=False)
		ObjectDictionary._init_state(self)
		BaseObject._init_setup(self, from_setup, from_default)

	def setup(self, params:Optional[Setup])->Any:
		"""
		The ObjectDictionary class is designed to act as a container for Strategy objectIds.
		It exposes the required methods to set/get its items.
		"""
		actual_params = BaseObject._apply_setup(obj=self, params=params) # if check_default_flag else params
		# actual_params = self.Defaults()
		# if params is not None:
		# 	actual_params.update(params)
		super().setup(actual_params)
		# pass
		return self

	def InFields(self, filer:QSFiler):
		# check status
		# check version
		if super().InFields(filer):
			stored_version:int = filer.pop()
			if stored_version == ObjectDictionary.__version:
				self._topics = filer.pop()
			elif stored_version == 1:
				old_obj_ids = filer.pop()
				self._topics[self.DefaultTopic] = old_obj_ids
		return True

	def OutFields(self, filer:QSFiler):
		if super().OutFields(filer):
			filer.push(ObjectDictionary.__version)
			filer.push(self._topics)
		return True

	def clear(self, topic:str="", delete_object:bool=False)->None:
		target_topics = list(self._topics.keys()) if topic=="" else [topic]
		to_be_deleted = []
		# 1-collect
		for curr_topic in target_topics:
			topic_exists = curr_topic in self._topics
			if topic_exists:
				if delete_object:
					ids = list(self._topics[curr_topic].values())
					to_be_deleted.extend(ids)
				self._topics[curr_topic].clear()
		# 2-delete
		for obj_id in to_be_deleted:
			DELETE(obj_id)

	@property
	def Topics(self)->List[str]:
		res=list(self._topics.keys())
		return res

	@property
	def AvailableTopics(self) -> List[str]:
		return []
	
	# deprecata da quando abbiamo definito le costanti per accedere ai dizionari
	@property
	def DefaultTopic(self)->str:
		return "default"
	
	def add(self, k:str, v:IntKEY, topic:str, delete_object:bool=True):
		"""Add or replace an object to the dictionary "to" of obj_ids
			Args: 
				k (str): object key name
				v (ooh.IntKEY): object id
				to (str, optional): topic name, default topic is "" and add object to "default"
				delete_object (bool, optional): whether to override an exisiting object with the same key
											   NB: override only if the id is not the same (id_object != id)
		"""
		# topic_value = self.DefaultTopic if topic == "" else topic
		topic_exists = topic in self._topics
		if not topic_exists:
			self._topics[topic] = {}
		
		if delete_object:
			id_object = self._topics[topic].get(k)
			if id_object is not None and id_object != v:
				DELETE(id_object)

		self._topics[topic][k] = v

	def get(self, k:str, topic:str) ->IntKEY:
		"""Get an object from the dictionary of obj_ids"""
		# topic_value = self.DefaultTopic if topic == "" else topic
		topic_exists = topic in self._topics
		
		if topic_exists and (k in self._topics[topic]):
			return self._topics[topic][k]
		return NullKEY
	
	def pop(self, k:str, topic:str) ->IntKEY:
		"""Pop an object from the dictionary of obj_ids"""
		res = NullKEY
		# topic_value = self.DefaultTopic if topic == "" else topic
		topic_exists = topic in self._topics

		if topic_exists and (k in self._topics[topic]):
			res = self._topics[topic].pop(k)
		return res

	def delete(self, k:str, topic:str) ->IntKEY:
		"""remove and delete an object from the dictionary of obj_ids"""
		res = self.pop(k, topic)
		if res != NullKEY:
			DELETE(res)
		return res

	def contains(self, k:str, topic:str)->bool:
		"""Check if the dictionary of obj_ids constains the key passed"""
		# topic_value = self.DefaultTopic if topic == "" else topic
		topic_exists = topic in self._topics

		return topic_exists and (self.get(k=k, topic=topic) != NullKEY)

	# @property
	def Ids(self, topic:str) ->List[IntKEY]:
		"""Get the list of the available values"""
		res = []
		# topic_value = self.DefaultTopic if topic == "" else topic
		topic_exists = topic in self._topics
		if topic_exists:
			res = list(self._topics[topic].values())
		return res

	# @property
	def Keys(self, topic:str) ->List[str]:
		"""Get the list of the available keys"""
		res = []
		# topic_value = self.DefaultTopic if topic == "" else topic
		topic_exists = topic in self._topics
		if topic_exists:
			res = list(self._topics[topic].keys())
		return res

class IObjectBuilder(ABC):

	def Register(self, name:str, cls:Any):
		pass
	def Build(self, classname:str, from_setup:Optional[TypedDict]=None, from_default:bool=False):
		pass

class ObjectBuilder(object):
	"""Class used to handle a Register with the name->class map of the objs and get it. Register objects saving its type."""
	def __init__(self) -> None:
		super().__init__()
		self._classes:Dict[str,Any] = {}

	def Register(self, name:str, cls:Any):
		"""Add an element to the registry"""
		self._classes[name] = cls

	def Build(self, classname:str, from_setup:Optional[TypedDict]=None, from_default:bool=False)->IObject:
		"""Get the class  from the registry asscoiated with the specified classname"""
		obj:IObject = self._classes[classname](from_setup, from_default)
		return obj

class IObjectHandler(ABC):
	
	#-----------------------------------------------------------------------------
	# Shared Methods implemented in BasoObjectHandler
	#-----------------------------------------------------------------------------
	
	""" Abstract class used to handle the objs
	"""
	@abstractmethod
	def Open(self, keyint:IntKEY, mode:OpenMode = OpenMode.ForWrite) ->Optional[IObject]:
		"""Open an object.

		Args:
			keyint (IntKEY): key associated with the object
			mode (OpenMode, optional): how to open the obj. Defaults to OpenMode.ForWrite.

		Returns:
			Optional[IObject]: opened object
		"""
		# raise NotImplementedError("Should implement method")

	@abstractmethod
	def Delete(self, keyint:IntKEY) -> None:
		"""Delete an object with the encoder

		Args:
			keyint (IntKEY): key of the object
		"""
		# raise NotImplementedError("Should implement method")

	@abstractmethod
	def IntKeys(self, cls:Optional[TGenericObject]=None) ->List[IntKEY]:
		"""Get the key of all the objects belonging to cls class

		Args:
			cls (TGenericObject, optional): Class of the object. Defaults to None.

		Returns:
			List[IntKEY]: List of keys of object
		"""
		# raise NotImplementedError("Should implement method")

	@abstractmethod
	def CheckKey(self, key:IntKEY) -> None:
		"""Check the consistency of the actual key"""
		# raise NotImplementedError("Should implement method")

	@abstractproperty
	def NextKey(self) -> BaseKey:
		"""Get the next id available"""
		# raise NotImplementedError("Should implement property")
	

	#-----------------------------------------------------------------------------
	# StorageEngine-Specific Methods to be implemented in each <derived>ObjectHandler
	#-----------------------------------------------------------------------------

	@abstractmethod
	def OpenObjectId(self, keyobj:BaseKey, mode:OpenMode=OpenMode.ForWrite) ->Optional[IObject]:
		"""Open the object

		Args:
			key (BaseKey): key of the object, referred in the native format (es 000000123 in MongoDB)\n
			mode (OpenMode, optional): how the object should be open. Defaults to OpenMode.ForWrite.

		Returns:
			TGenericObject: the object opened
		"""

	@abstractmethod
	def Close(self, obj:IObject) ->None:
		"""Close an object

		Args:
			obj (TGenericObject): object to be closed
		"""
	
	@abstractmethod
	def DeleteObjectId(self, key:BaseKey) ->None:
		"""Delete an object with the encoder

		Args:
			keyint (BaseKey): key of the object, referred in the native format (es 000000123 in MongoDB)\n
		"""

	@abstractmethod
	def Clear(self) ->None:
		"""Clear the encoder"""

	@abstractmethod
	def BaseKeys(self, cls:Optional[TGenericObject]=None) ->List[BaseKey]:
		"""Get the list of native Key of an object based on its type

		Args:
			cls (TGenericObject, optional)

		"""

	@abstractmethod
	def _internal_keys(self) ->List[Any]:
		"""Get the list of native Key of an object based on its type

		Args:
			objtype (objectClass, optional)

		"""

#"""Class that describes the basic configurations of a Context object, such as the data dir, the output dir, the object counter, etc."""
class ContextConfig(DataStruct):
	PRJ_NAME:str = ""
	DATA_DIR:str = ".\\data"    #from_env("DATA_DIR", "~/data"),
	OUTPUT_DIR:str = ".\\out"   #from_env("OUTPUT_DIR", "~/out"),
	OBJECT_COUNTER:int = 0
	OBJECT_STORE_TYPE:str = "MEM_DICT"
	PRJ_STORE_TYPE:str = "MEM_DICT"
	LOG_STORE_TYPE:str = "MEM"
	DB_HOST:str = "127.0.0.1"
	DB_PORT:int = 27017
	QUERY_TIMEOUT:int = 60000
	LOG_TOPICS:List[str] = ["Default"]
	PLUGIN_DIR:str = "object_handler/plugins"

class ContextContainer(ContextConfig):
	"""Class that describe the main elements of a Context object, which are its class, the object store, the project store, the log store and the logger"""
	CLASS_BUILDER:object = None     #Optional[ObjectBuilder ]= None
	OBJECT_STORE:object = None      #:Optional[BaseObjectHandler] = None
	PRJ_STORE:object = None         #:Optional[BaseObjectHandler] = None
	LOG_STORE:object = None         #:Optional[BaseObjectHandler] = None
	LOGGER:Dict[str,object] = {}    #:Optional[BaseObjectHandler] = None

class BaseObjectHandler(IObjectHandler, BaseCounter):
	""" Base class that handles an object
	"""

	_DEFAULT_Instance:ContextContainer=ContextContainer({})

	def __init__(self, storage:TStorage=None, encoder:Optional[str]=None, builder:Optional[ObjectBuilder]=None):
		super().__init__()
		self.__encoder:Optional[str] = encoder
		self.__storage:TStorage = storage
	
	@property
	def Encoder(self) -> Optional[str]:
		"""Get the encoder"""
		return self.__encoder
	def SetEncoder(self, encoder:str) -> None:
		"""Set the encoder"""
		self.__encoder = encoder

	@property
	def Storage(self) -> TStorage:
		"""Get the storage"""
		return self.__storage
	def SetStorage(self, storage:TStorage) -> None:
		"""Set the storage"""
		self.__storage = storage


	#----------------------------------------------------------------------------------------
	# Interface shared implementations
	#----------------------------------------------------------------------------------------

	def Open(self, keyint:IntKEY, mode:OpenMode = OpenMode.ForWrite) ->Optional[IObject]:
		"""Open the object

		Args:
			keyint (IntKEY): key of the object to be opened\n
			mode (OpenMode, optional): how the object should be open. Defaults to OpenMode.ForWrite.

		Returns:
			TGenericObject: the object opened
		"""
		return self.OpenObjectId(keyobj=BaseKey(keyint), mode=mode)

	def Delete(self, keyint:IntKEY) -> None:
		"""Delete an object with the encoder

		Args:
			keyint (IntKEY): key of the object
		"""
		return self.DeleteObjectId(BaseKey(keyint))

	def IntKeys(self, cls:Optional[TGenericObject]=None) ->List[IntKEY]:
		"""Get the key of all the objects belonging to cls class

		Args:
			cls (TGenericObject, optional): Class of the object. Defaults to None.

		Returns:
			List[IntKEY]: List of keys of object
		"""
		ikeys = [x.asIntKey() for x in self.BaseKeys(cls)]
		return ikeys
	
	def CheckKey(self, key:IntKEY) -> None:
		"""Check the consistency of the actual key"""
		if key >= self.Count():
			self.ResetCount(key)

	@property
	def NextKey(self) -> BaseKey:
		return BaseKey(self.NextCount())


# ObjectHandler generics
TGenericObjectHandler = TypeVar('TGenericObjectHandler', bound=IObjectHandler)

#-----------------------------------------------------------------------
# Current Context parameters ---> BaseObjectHandler._DEFAULT_Instance
#

def DEFAULT() ->ContextContainer:
	"""Get the default value of a ContextContainer"""
	return BaseObjectHandler._DEFAULT_Instance
	
def SET_AS_DEFAULT(other_conf:ContextContainer):
	"""Set the default values in this class from another ContextConfig"""
	# from ContextConfig
	BaseObjectHandler._DEFAULT_Instance.DATA_DIR = other_conf.DATA_DIR
	BaseObjectHandler._DEFAULT_Instance.OUTPUT_DIR = other_conf.OUTPUT_DIR
	BaseObjectHandler._DEFAULT_Instance.OBJECT_COUNTER = other_conf.OBJECT_COUNTER
	BaseObjectHandler._DEFAULT_Instance.OBJECT_STORE_TYPE = other_conf.OBJECT_STORE_TYPE
	BaseObjectHandler._DEFAULT_Instance.PRJ_STORE_TYPE = other_conf.PRJ_STORE_TYPE
	BaseObjectHandler._DEFAULT_Instance.LOG_STORE_TYPE = other_conf.LOG_STORE_TYPE
	BaseObjectHandler._DEFAULT_Instance.LOG_TOPICS = other_conf.LOG_TOPICS
	BaseObjectHandler._DEFAULT_Instance.PLUGIN_DIR = other_conf.PLUGIN_DIR
	# from ContextConfig/ContextContainer
	BaseObjectHandler._DEFAULT_Instance.CLASS_BUILDER = other_conf.CLASS_BUILDER
	BaseObjectHandler._DEFAULT_Instance.OBJECT_STORE = other_conf.OBJECT_STORE
	BaseObjectHandler._DEFAULT_Instance.PRJ_STORE = other_conf.PRJ_STORE
	#
	BaseObjectHandler._DEFAULT_Instance.LOG_STORE = other_conf.LOG_STORE
	BaseObjectHandler._DEFAULT_Instance.LOGGER = other_conf.LOGGER
#-----------------------------------------------------------------------
# object IO cmds

def CLOSE(obj:Optional[IObject], engine:Optional[IObjectHandler] = None) -> IntKEY:
	"""Close an object opened with engine

	Args:
		obj (TGenericObject): oject to be closed\n
		engine (Optional[BaseObjectHandler], optional): encoder used. If None, the default object store is used. Defaults to None.

	Returns:
		IntKEY: Key of the object closed
	"""
	res = NullKEY
	if obj is not None:
		dbengine:IObjectHandler = DEFAULT().OBJECT_STORE if engine is None else engine  #engine or DEFAULT().OBJECT_STORE
		try:
			# anticipo controllo da fare comunque nella Close() del driver/connector
			if obj.Status in [OpenMode.ForWrite, OpenMode.New]:
				dbengine.Close(obj)
				res = obj.Id
			obj.Status = OpenMode.Closed
			# liberare risorse ? todo in implementation, not here !
			# del obj
		except Exception as e:
			print("Engine: "+str(dbengine.__class__)+"Something wrong when saving Object: "+obj.ClassName)
			print(e)
			res = NullKEY
		finally:
			return res
	return res

def ADD(obj:IObject, engine:Optional[IObjectHandler] = None) -> IntKEY:
	"""Add an object to the engine

	Args:
		obj (TGenericObject): object to be added\n
		engine (Optional[BaseObjectHandler], optional): encoder to use. If None, the default object store is used. Defaults to None.

	Returns:
		IntKEY: Key of the added object
	"""
	# if obj.Status in [OpenMode.New]:
	res = NullKEY
	dbengine:IObjectHandler = DEFAULT().OBJECT_STORE if engine is None else engine  #engine or DEFAULT().OBJECT_STORE
	if dbengine is not None:
		key = dbengine.NextKey
		obj.Status = OpenMode.New 
		obj.Id = key.asIntKey()
		res = CLOSE(obj, engine=dbengine)
	else:
		print("None Engine error")
	return res

def ADDK(obj:IObject, keyint:IntKEY, engine:Optional[IObjectHandler] = None) -> IntKEY:
	"""Add an object to the engine using the defined key

	Args:
		obj (TGenericObject): object to be added\n
		keyint (IntKEY): key to be used\n
		engine (Optional[BaseObjectHandler], optional): encoder used. If None, the default object store is used. Defaults to None.

	Returns:
		IntKEY: key produced when the object has been added
	"""
	# if obj.Status in [OpenMode.New]:
	res = NullKEY
	dbengine:IObjectHandler = DEFAULT().OBJECT_STORE if engine is None else engine
	if dbengine is not None:
		dbengine.CheckKey(keyint)
		obj.Status = OpenMode.New 
		obj.Id = keyint
		res = CLOSE(obj, engine=dbengine)
	else:
		print("None Engine error")
	return res

@contextmanager
def GET(key:IntKEY, mode:OpenMode=OpenMode.ForWrite, engine:Optional[IObjectHandler] = None):
	"""Get an object with a specific key, using a specific mode and engine

	Args:
		key (IntKEY): key of the object to be opened\n
		mode ([type], optional): open mode. Defaults to OpenMode.ForWrite.\n
		engine (Optional[BaseObjectHandler], optional): encoder. If None, the default object store is used. Defaults to None.\n

	Returns:
		Optional[TGenericObject]: object opened
	"""
	obj:Optional[IObject] = None
	dbengine:IObjectHandler = DEFAULT().OBJECT_STORE if engine is None else engine
	try:
		obj = dbengine.Open(keyint=key, mode=mode)
		if obj is not None: 
			yield obj
		else:
			print("Engine: "+str(dbengine.__class__)+" Key not found when opening Key: "+str(key)) 
			   
	except Exception as e:
		print("Engine: "+str(dbengine.__class__)+" Something wrong when opening Key: "+str(key))
		print(e)
		obj = None
	finally:
		CLOSE(obj, engine=dbengine)

def OPEN(key:IntKEY, mode:OpenMode=OpenMode.ForWrite, engine:Optional[IObjectHandler] = None, cls:Optional[TGenericObject]=None) -> Optional[IObject]:
	"""Open an object with a specific key, using a specific mode, engine and class

	Args:
		key (IntKEY): key of the object to be opened\n
		mode ([type], optional): open mode. Defaults to OpenMode.ForWrite.\n
		engine (Optional[BaseObjectHandler], optional): encoder. If None, the default object store is used. Defaults to None.\n
		cls (Optional[TGenericObject], optional): Class of the object. Defaults to None

	Returns:
		Optional[TGenericObject]: object opened
	"""
	obj:Optional[IObject] = None
	dbengine:IObjectHandler = DEFAULT().OBJECT_STORE if engine is None else engine
	try:
		obj = dbengine.Open(keyint=key, mode=mode)
	except Exception as e:
		print("Engine: "+str(dbengine.__class__)+" Something wrong when opening Key: "+str(key))
		print(e)
		obj = None
	finally:
		return obj

def OPENK(key:BaseKey, mode:OpenMode=OpenMode.ForWrite, engine:Optional[IObjectHandler] = None, cls:Optional[TGenericObject]=None) -> Optional[IObject]:
	"""Open an object with a specific key, using a specific mode and engine

	Args:
		key (BaseKey): key of the object to be opened, referred in the native format (es 000000123 in MongoDB)\n
		mode ([type], optional): open mode. Defaults to OpenMode.ForWrite.\n
		engine (Optional[BaseObjectHandler], optional): encoder. If None, the default object store is used. Defaults to None.\n
		cls (Optional[TGenericObject], optional): Class of the object. Defaults to None

	Returns:
		Optional[TGenericObject]: object opened
	"""
	obj:Optional[IObject] = None
	dbengine:IObjectHandler = DEFAULT().OBJECT_STORE if engine is None else engine
	try:
		obj = dbengine.OpenObjectId(keyobj=key, mode=mode)
	except Exception as e:
		print("Engine: "+str(dbengine.__class__)+" Something wrong when opening Key: "+str(key))
		print(e)
		obj = None
	finally:
		return obj

def DELETE(key:IntKEY, engine:Optional[IObjectHandler] = None) -> None:
	"""Delete an object using the engine

	Args:
		key (IntKEY): key object to be deleted\n
		engine (Optional[BaseObjectHandler], optional): encoder. If None, the default object store is used. Defaults to None.
	"""
	dbengine:IObjectHandler = DEFAULT().OBJECT_STORE if engine is None else engine
	obj = dbengine.Open(keyint=key, mode=OpenMode.ForWrite)
	if obj is not None:
		obj.on_delete()
	dbengine.Delete(key)

def DELETEK(key:BaseKey, engine:Optional[IObjectHandler] = None) -> None:
	"""Delete an object using the engine

	Args:
		key (BaseKey): key object to be deleted, referred in the native format (es 000000123 in MongoDB)\n
		engine (Optional[BaseObjectHandler], optional): encoder. Defaults to None.
	"""
	dbengine:IObjectHandler = DEFAULT().OBJECT_STORE if engine is None else engine
	dbengine.DeleteObjectId(key)

#-----------------------------------------------------------------------